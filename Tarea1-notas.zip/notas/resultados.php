<?php
$notas = array("Matemáticas" => array("Trimestre 1" => 3,
									  "Trimestre 2" => 10,
									  "Trimestre 3" => 7),
			   "Lengua" => array("Trimestre 1" => 8,
								 "Trimestre 2" => 5,
								 "Trimestre 3" => 3),
			   "Física" => array("Trimestre 1" => 7,
								 "Trimestre 2" => 2,
								 "Trimestre 3" => 1),
			   "Latín" => array("Trimestre 1" => 4,
								"Trimestre 2" => 7,
								"Trimestre 3" => 8),
			   "Inglés" => array("Trimestre 1" => 6,
								 "Trimestre 2" => 2,
								 "Trimestre 3" => 3));
?>